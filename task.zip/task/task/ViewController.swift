//
//  ViewController.swift
//  task
//
//  Created by Setblue's iMac on 01/04/19.
//  Copyright © 2019 I MAC. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var tbl: UITableView!
    var finalarr:[[String:Any]] = []
    var expandbut = Int()
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       self.callApi()
        // tbl.delegate = self
        //tbl.dataSource = self
    }
//    func json() {
//        let url = URL(string: "http://maestro.jodhaa.co.in/api/teacher/assignments/completed");
//        let peram = ["teacher_id":1];
//
//        do{
  //          let body = try JSONSerialization.data(withJSONObject: peram, options: [])
//            var request = URLRequest(url: url!)
    
//            request.addValue("application/json", forHTTPHeaderField: "Content-Type")            request.httpBody = body
//            request.httpMethod = "POST"
//            let session = URLSession.shared
//            let datatask = session.dataTask(with: request) { (data1, respons, error) in
//
//
//            }
//            
//            datatask.resume()
//        }catch{
//
//        }
//
//    }

    func callApi() {
        let params = ["teacher_id":1] as Dictionary<String, AnyObject>
        
        var request = URLRequest(url: URL(string: "http://maestro.jodhaa.co.in/api/teacher/assignments/completed")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
//            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! [String:Any]
            //    print(json)
                self.finalarr = json["Data"]! as! [[String : Any]]
           //     print(self.finalarr)
                DispatchQueue.main.async {
                 self.tbl.reloadData()
                }
                
                
            } catch {
                print("error")
            }
        })
        
        task.resume()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return finalarr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)as! coscell
        let dic = finalarr[indexPath.section]
//        print(dic)
        
        cell.lblname.text = (dic["User_fullname"] as! String)
        cell.lblassign.text = (dic["User_notes"] as! String)
        var val = Int()
        val = Int(dic["User_rate"]as! NSNumber)
        cell.lblretvalue.text = String(val)
        var val1 = Int()
        val = Int(dic["Total_assignment_completed"]as! NSNumber)
        cell.lblassign.text = String(val1)
        let url = URL(string: dic["Profile"] as! String)
        cell.viewbut.tag = indexPath.section
        cell.viewbut.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        cell.viewbut.accessibilityIdentifier = String(indexPath.section)
        if dic["IsExpanded"] as! String == "0" {
            cell.viewbut.backgroundColor = UIColor.red
        }else{
            cell.viewbut.backgroundColor = UIColor.green
        }
        
        do{
            let imgdata = try Data(contentsOf: url!)
            cell.imageview.image = UIImage(data: imgdata)
            
        }catch{
            
        }
        
        return cell
    }

    var indexOfCellToExpand: Int!
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let index = IndexPath(row: 0, section: 0)
        let cell = tbl.cellForRow(at: index)as! coscell
        if indexPath.section == indexOfCellToExpand {
            return 230.0 + cell.expendlbl.frame.height - 50
            
        }
       
           return 230.0
        
    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//
//
//    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 230.0
    }
    @objc func test(sender: UIButton)  {
        let index = IndexPath(row: 0, section: sender.tag)
        let cell = tbl.cellForRow(at: index)as! coscell
        
         cell.viewbut.backgroundColor = UIColor.green
        var dict = self.finalarr[Int(sender.accessibilityIdentifier!)!]
        if dict["IsExpanded"] as! String == "0" {
            dict["IsExpanded"] = "1"
        }
        else {
            dict["IsExpanded"] = "0"
        }
        self.finalarr[Int(sender.accessibilityIdentifier!)!] = dict
        print("button index \(sender.accessibilityIdentifier)")
        
        self.tbl.reloadData()
        
    }
}

