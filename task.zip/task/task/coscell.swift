//
//  coscell.swift
//  task
//
//  Created by Setblue's iMac on 01/04/19.
//  Copyright © 2019 I MAC. All rights reserved.
//

import UIKit

class coscell: UITableViewCell {

    @IBOutlet weak var expendlbl: UILabel!
    @IBOutlet weak var viewbut: UIButton!
    @IBOutlet weak var lblassign: UILabel!
    @IBOutlet weak var lblretvalue: UILabel!
    @IBOutlet weak var retingstar: UILabel!
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var imageview: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
